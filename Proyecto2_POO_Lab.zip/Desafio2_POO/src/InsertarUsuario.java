import conexion.My_jvdc;
import utilidades.Encriptador;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertarUsuario {
    public static void main(String[] args) {
        try (Connection conn = My_jvdc.getConnection()) {
            String usuario = "admin";
            String passwordPlano = "admin123";
            String passwordHash = Encriptador.encriptar(passwordPlano);

            String sql = "INSERT INTO usuario (username, password) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, passwordHash);
            stmt.executeUpdate();

            System.out.println("Usuario creado exitosamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
