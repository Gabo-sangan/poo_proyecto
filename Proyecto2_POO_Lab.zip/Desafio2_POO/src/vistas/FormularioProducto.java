package vistas;

import dao.ProductoDAO;
import modelo.Producto;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FormularioProducto extends JDialog {
    private JTextField txtNombre, txtPrecio, txtCantidad, txtFecha;
    private JButton btnGuardar;
    private Producto producto;
    private ProductoDAO dao = new ProductoDAO();
    private InventarioFrame parent;

    public FormularioProducto(InventarioFrame parent, Producto producto) {
        super(parent, true);
        this.parent = parent;
        this.producto = producto;

        setTitle(producto == null ? "Agregar Producto" : "Editar Producto");
        setSize(300, 250);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        add(txtNombre);

        add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        add(txtPrecio);

        add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        add(txtCantidad);

        add(new JLabel("Fecha Expiración (yyyy-MM-dd):"));
        txtFecha = new JTextField();
        add(txtFecha);

        btnGuardar = new JButton("Guardar");
        add(btnGuardar);

        if (producto != null) {
            txtNombre.setText(producto.getNombre());
            txtPrecio.setText(String.valueOf(producto.getPrecio()));
            txtCantidad.setText(String.valueOf(producto.getCantidad()));
            txtFecha.setText(new SimpleDateFormat("yyyy-MM-dd").format(producto.getFechaExpiracion()));
        }

        btnGuardar.addActionListener(e -> guardarProducto());
    }

    private void guardarProducto() {
        try {
            String nombre = txtNombre.getText();
            double precio = Double.parseDouble(txtPrecio.getText());
            int cantidad = Integer.parseInt(txtCantidad.getText());
            Date fecha = new SimpleDateFormat("yyyy-MM-dd").parse(txtFecha.getText());

            if (producto == null) {
                producto = new Producto();
            }

            producto.setNombre(nombre);
            producto.setPrecio(precio);
            producto.setCantidad(cantidad);
            producto.setFechaExpiracion(fecha);

            if (producto.getId() > 0) {
                dao.actualizar(producto);
            } else {
                dao.insertar(producto);
            }

            parent.cargarProductos();
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}
