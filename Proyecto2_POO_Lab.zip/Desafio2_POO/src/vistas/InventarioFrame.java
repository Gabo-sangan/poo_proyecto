package vistas;

import dao.ProductoDAO;
import modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class InventarioFrame extends JFrame {
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private ProductoDAO productoDAO = new ProductoDAO();

    public InventarioFrame() {
        setTitle("Inventario de Productos");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear tabla
        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Precio", "Cantidad", "Expiración"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);

        // Botones
        JButton btnAgregar = new JButton("Agregar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        // Agregar al frame
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        cargarProductos();

        // Evento: Agregar
        btnAgregar.addActionListener(e -> {
            new FormularioProducto(this, null).setVisible(true);
        });

        // Evento: Editar
        btnEditar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila >= 0) {
                long id = Long.parseLong(modeloTabla.getValueAt(fila, 0).toString());
                Producto producto = productoDAO.buscarPorId(id);
                new FormularioProducto(this, producto).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un producto.");
            }
        });

        // Evento: Eliminar
        btnEliminar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila >= 0) {
                long id = Long.parseLong(modeloTabla.getValueAt(fila, 0).toString());
                int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar producto?");
                if (confirm == JOptionPane.YES_OPTION) {
                    productoDAO.eliminar(id);
                    cargarProductos();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un producto.");
            }
        });

        setVisible(true);
    }

    public void cargarProductos() {
        modeloTabla.setRowCount(0);
        List<Producto> lista = productoDAO.listarProductos();
        for (Producto p : lista) {
            modeloTabla.addRow(new Object[]{
                    p.getId(), p.getNombre(), p.getPrecio(), p.getCantidad(), p.getFechaExpiracion()
            });
        }
    }
}
