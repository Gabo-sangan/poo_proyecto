package vistas;

import dao.UsuarioDAO;

import javax.swing.*;

public class Login {
    public Login() {
        String usuario = JOptionPane.showInputDialog("Usuario:");
        String contrasena = JOptionPane.showInputDialog("Contraseña:");

        UsuarioDAO dao = new UsuarioDAO();
        boolean ok = dao.validarLogin(usuario, contrasena);

        if (ok) {
            JOptionPane.showMessageDialog(null, "¡Bienvenido!");
            new InventarioFrame(); // mostrar inventario
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.");
        }
    }
}
