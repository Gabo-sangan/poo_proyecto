package modelo;

import java.util.Date;

public class Producto {
    private long id;
    private String nombre;
    private double precio;
    private int cantidad;
    private Date fechaExpiracion;

    // Constructor vacío
    public Producto() {}

    // Constructor con parámetros
    public Producto(long id, String nombre, double precio, int cantidad, Date fechaExpiracion) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.fechaExpiracion = fechaExpiracion;
    }

    // Getters y Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public Date getFechaExpiracion() { return fechaExpiracion; }
    public void setFechaExpiracion(Date fechaExpiracion) { this.fechaExpiracion = fechaExpiracion; }
}
