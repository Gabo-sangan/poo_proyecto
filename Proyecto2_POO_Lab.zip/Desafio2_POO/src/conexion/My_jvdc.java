package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class My_jvdc {
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/tienda";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "poo1";

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USUARIO, CONTRASENA);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }
}
