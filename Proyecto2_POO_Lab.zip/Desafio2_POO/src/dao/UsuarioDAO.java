package dao;

import conexion.My_jvdc;
import utilidades.Encriptador;

import java.sql.*;

public class UsuarioDAO {
    public boolean autenticar(String username, String password) {
        String sql = "SELECT password FROM usuario WHERE username = ?";
        try (Connection conn = My_jvdc.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String hashAlmacenado = rs.getString("password");
                return Encriptador.verificar(password, hashAlmacenado);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}


